#######################################_________________Completed By_________________######################################################

Name: Rashik Rahman
ID: 17201012
Sec: A

#######################################_________________USER MANUAL_________________######################################################
###Keyboard Functions

'w': Move up
's': Move down
'd': Move right
'a': Move left

'c': Color toggle(Changes color each time pressed)
't': Enable/Disable smooth transitions among colors

UP_arrow_key: UP key to move the light source UP
DOWN _arrow_key: DOWN key to move the light source DOWN
LEFT _arrow_key: LEFT key to move the light source LEFT
RIGHT _arrow_key: : RIGHT key to move the light source RIGHT

'r': Enable/Disable auto spin of the object

'+': smoothens suface
'-': makes surface edge rough

###Mouse Function

'e': Switch between rotation or zoom using mouse action. When pressed once you can zoom-in with left click and zoom-out with right click of mouse. When pressed again you can rotate anticlockwise with with left click 
     and clockwise with right click of mouse.


**A short video is also given for ease of use**

#######################################_________________Q&A_________________######################################################


A. Did you collaborate with anyone in the class? If so, let us know who you talked to and what sort of help you gave or received.

Answer: I didn’t collaborate with anyone of my class. I just followed the class lectures and learned some extra things from Google, Stackoverflow, Qura and Youtube.


B. Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment? Please provide a list.

Answer: Stackoverflow and ‘community.khronos.org’ helped me a lot to complete this assignment, especially the smooth color trabsition and rotation using mouse part. I also took help from reddit.com opengl discussion.


C. Are there any known problems with your code? If so, please provide a list and, if possible, describe what you think the cause is and how you might fix them if you had more time or motivation. 
This is very important, as we’re much more likely to assign partial credit if you help us understand what’s going on.

Answer: I could not implement zoom using mouse scroll but. I didn’t spend too much time as it was still working enough well as per requirement and I was able to zoom using left/right click. I faced a lot of problems in smooth color 
	transition and rotate/zoom using mouse action. 


D. Did you do any extra work? If so, let us know how to use the additional features. If there was a substantial amount of work involved, describe what and how you did it.

Answer: Incase of extra work I just added movement of the object. Using 'w','a','s','d' the object can be moved.


E. Got any comments about this assignment that you’d like to share? Was it too long? Too hard? Were the requirements unclear? Did you have fun, or did you hate it? Did you learn something, or was it a total waste of your time?

Answer: The assignment was not too long or too hard. This was not that hard because someone with basic understanding of coding and OpenGl will be able to do it effortlessly.  In short I can say I did enjoy the task.

