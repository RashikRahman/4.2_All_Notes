1. For Color changes = press C
2. For Light postioning changes = press Leftwards/Rightwards/Upwards/Downwards Arrow key
3. For Spin = press R